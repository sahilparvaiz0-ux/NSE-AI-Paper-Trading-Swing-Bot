# Nifty-50 Swing-Trading Bot with AI Trade-Quality Validation

**Financial and Risk Analytics — Individual Assignment**  
Sahil Parveez | MBA Business Analytics & AI | CHRIST (Deemed to be) University, Delhi NCR

## Scope

End-to-end historical backtest of a long-only swing-trading bot for ten NSE Nifty-50 constituents using real daily OHLCV data from **2020-10-01 to 2025-09-30**. The project combines technical-rule signals, ATR-based portfolio risk controls, transaction-cost modelling, explicit cash accounting, chronological out-of-sample validation and a separately evaluated Random Forest AI trade-quality filter.

No live orders are placed and no brokerage account is connected.

## Strategy

- Entry: EMA(20/50) upward crossover + RSI(14) in [40,70] + MACD histogram > 0.
- Signal timing: detected at day T close and executed at day T+1 open.
- Exit: 2×ATR stop-loss, 4×ATR take-profit, EMA cross-down or RSI > 80; signal exits execute at the next open.
- Risk: 1% of portfolio equity per trade, maximum 5 concurrent positions, maximum 25% single-position allocation.
- Costs: 0.03% brokerage + 0.05% slippage on each leg, with 0.10% STT on the sell leg.
- Cash: only uninvested cash accrues the modelled 6.5% annual rate.

## Five-year baseline results

Starting capital **Rs 10,00,000**; ending equity **Rs 15,34,922**; total return **53.49%**; CAGR **8.95%**; annualised volatility **6.94%**; Sharpe **0.35**; Sortino **0.51**; maximum drawdown **-7.74%**; **98 closed trades**; win rate **44.0%**; profit factor **1.36**; expectancy **Rs 2,349 per trade**.

The modelled cash-only baseline at 6.5% ends at approximately **Rs 13,69,791**. The five-year equity gain is approximately **Rs 5.35 lakh**, of which **Rs 2.30 lakh (43.0%)** is net trading P&L and **Rs 3.05 lakh (57.0%)** is modelled idle-cash interest. Average capital deployment is **28.1%**, and the portfolio is fully in cash on **33.8%** of recorded days.

## Risk analytics

Historical one-day tail-risk measures from the portfolio equity series:

- 95% VaR: **-0.62%**
- 95% CVaR / expected shortfall: **-1.04%**
- 99% VaR: **-1.23%**
- 99% CVaR: **-1.68%**
- Worst observed daily return: **-3.13%**
- Excess kurtosis: **8.49**
- Longest underwater period: **204 trading days**

A stationary block bootstrap using 2,000 resamples and a mean block length of 35 trading days gives a 90% diagnostic interval of **[-0.30, 1.01]** for Sharpe. The interval crosses zero and is not treated as evidence of persistent skill.

## Benchmark and exposure controls

- Nifty 50 price index endpoint return: **116.27%**.
- Equal-weight 10-stock price-return proxy: **117.89%** on a daily-rebalanced basis. The **129.32%** figure is only the arithmetic average of the ten stocks' individual cumulative returns.
- Volatility-matched passive control: **48.6% basket / 51.4% cash**, with **74.29%** cumulative return, **6.94%** annualised volatility, Sharpe **0.73**, and maximum drawdown **-6.26%**.
- Market-model regression: beta **0.26**, annualised alpha **-0.23%**, alpha t-statistic **-0.09**, R² **0.28**.

The benchmark analysis is descriptive. The Nifty 50 index is a price index endpoint rather than a total-return series, and the stock-basket calculations exclude dividends.

## Out-of-sample validation

- In-sample: **2020-10-01 to 2024-09-30**.
- Held-out: **2024-10-01 to 2025-09-30**.
- 20 parameter combinations tested only in-sample.
- Baseline full-period configuration: EMA(20/50), RSI[40,70], 2×ATR stop / 4×ATR target.
- Best in-sample selected OOS configuration: **EMA(10/30), RSI[40,70], 3×ATR stop/target** with Sharpe **0.92**.
- Rule-based OOS return: **-8.48%**, Sharpe **-2.33**, 41 trades.

This is a **single chronological train/test split**, not rolling walk-forward re-optimisation.

## AI integration

A Random Forest classifier is used as a separate trade-quality filter. Features include EMA spread, RSI, MACD histogram relative to price, ATR relative to price, one-day return, five-day return and 20-day volume z-score. The target is 1 when the closing price five trading days after the signal date is above the signal-date close, and 0 otherwise. The model is trained on the broader in-sample ticker-date observations and then used to filter rule-based entries.

The model is trained only through **2024-09-30**, frozen before OOS testing, and uses an ex-ante **0.50 probability threshold**. Random Forest was selected for its ability to capture non-linear interactions among mixed technical features without feature scaling. The 0.50 threshold is the conventional equal-probability cutoff and was not tuned on OOS data.

- OOS accuracy: **50.96%**
- OOS AUC: **0.516**
- AI-filtered OOS return: **-4.68%**
- AI-filtered OOS Sharpe: **-2.04**
- AI-filtered trades: **34**
- AI-filtered profit factor: **0.43**

The AI result is treated as methodological integration and a measurable filtering effect, not as evidence of predictive superiority.

## Random-entry null model

A diagnostic null model using 2,000 simulations uses the same 98-trade count, the same universe, the empirical holding-period distribution and sampled trade notionals while randomising stock and entry date. The actual strategy net trading P&L is **Rs 2,30,249**, versus a null mean of **Rs 2,41,526**. The actual result is at the **48.3rd percentile**, with a one-sided p-value of **0.517**; **91.6%** of random runs were profitable. This is treated as a diagnostic null model rather than a definitive statistical test.

## Reproducibility

1. Install dependencies from `requirements.txt`.
2. Keep `data/nifty_data.xlsx` as the authoritative five-year snapshot.
3. Run `src/main.py` for the baseline backtest and core charts/logs.
4. Run `src/sensitivity_analysis.py` for the in-sample grid.
5. Run `src/walk_forward.py` for chronological OOS validation.
6. Run `src/ai_oos_validation.py` for the frozen AI filter.
7. Run `src/advanced_analysis.py` for VaR/CVaR, attribution, passive controls, regression, null-model and bootstrap diagnostics.
8. Run `src/audit_check.py` for the final integrity checks.

## Interpretation

The project does not claim guaranteed profitability or a persistent trading edge. The negative held-out result, weak AI AUC, near-centre random-entry percentile and risk-matched passive control are retained as findings. The value of the project is the reproducible integration of trading rules, financial risk controls, AI validation and adversarial evaluation.
